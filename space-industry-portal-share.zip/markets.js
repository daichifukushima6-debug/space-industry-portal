(() => {
  "use strict";

  const pending = { world: "調査中", japan: "調査中" };
  const BUSINESS_CASES = {
    launch: [
      {title:"専用ロケットによる衛星投入",customer:"地球観測・通信衛星事業者、宇宙機関",use:"希望する軌道と時刻へ衛星を直接投入し、運用開始までの時間を短縮する。",revenue:"打上げ1回ごとの契約＋ミッション統合作業費",example:"Rocket Lab Electron、三菱重工業 H-IIA/H3"},
      {title:"ライドシェア打上げ",customer:"大学、実証衛星スタートアップ、IoT事業者",use:"複数の小型衛星を相乗りさせ、単独打上げより低い費用で軌道へ運ぶ。",revenue:"衛星重量・搭載枠ごとの従量課金",example:"SpaceX Transporter、各社の小型衛星相乗りサービス"}
    ],
    "satellite-manufacturing": [
      {title:"コンステレーション量産",customer:"衛星通信・地球観測コンステレーション事業者",use:"共通衛星バスをライン生産し、数十〜数百機を短期間で供給する。",revenue:"設計開発費＋機体単価＋保守契約",example:"通信・地球観測向け小型衛星のバッチ生産"},
      {title:"ミッション一括構築",customer:"政府、研究機関、非宇宙企業",use:"要件定義から衛星製造、試験、打上げ調整、初期運用までを一括提供する。",revenue:"ターンキー契約＋運用支援の継続課金",example:"Axelspace、Open Cosmosの衛星プラットフォーム"}
    ],
    components: [
      {title:"宇宙グレード部品供給",customer:"ロケット・衛星メーカー",use:"放射線、真空、熱サイクルに耐える半導体、光部品、ケーブル、構造材を供給する。",revenue:"認定部品の販売＋個別設計・試験費",example:"耐放射線電子部品、光トランシーバー、CFRP構造材"},
      {title:"小型衛星向け推進モジュール",customer:"CubeSat・小型衛星メーカー",use:"軌道変更や衝突回避、運用終了時の離脱に使う推進系をモジュールで提供する。",revenue:"機器販売＋統合エンジニアリング費",example:"Pale Blueの水推進、Morpheus Spaceの電気推進"}
    ],
    "ground-station": [
      {title:"Ground Station as a Service",customer:"小型衛星運用者、大学、宇宙スタートアップ",use:"世界各地のアンテナを共同利用し、衛星との通信パスを必要な分だけ購入する。",revenue:"通信時間・パス単位の従量課金＋月額",example:"AWS Ground Station、KSAT Lite、Infostellar"},
      {title:"24時間ミッション管制",customer:"複数衛星を保有する事業者",use:"テレメトリ監視、コマンド送信、異常時対応を遠隔運用センターが代行する。",revenue:"衛星1機あたりの月額運用契約",example:"管制運用BPO、クラウド型Mission Control"}
    ],
    communications: [
      {title:"圏外地域向けブロードバンド",customer:"家庭、自治体、通信キャリア、企業拠点",use:"光回線が届かない地域へ衛星経由で高速通信を提供し、デジタル格差を縮小する。",revenue:"端末販売＋月額通信料",example:"Starlink、Eutelsat OneWeb、地域向けAstranis"},
      {title:"航空・海運の常時接続",customer:"航空会社、船社、オフショア事業者",use:"移動体へ乗客用Wi-Fi、運航データ、乗員通信を提供する。",revenue:"機体・船舶単位の機器費＋通信契約",example:"航空機内Wi-Fi、商船・クルーズ船の衛星通信"}
    ],
    "earth-observation": [
      {title:"災害発生時の迅速な被害把握",customer:"自治体、保険会社、インフラ事業者",use:"光学・SAR画像から浸水、土砂崩れ、建物損壊を抽出し、初動判断へ提供する。",revenue:"画像・解析レポート販売＋緊急対応契約",example:"ICEYEの洪水分析、Synspectiveの災害モニタリング"},
      {title:"経済活動・設備の定期監視",customer:"商社、製造業、金融機関、政府",use:"港湾、工場、貯蔵設備、建設現場の変化を継続観測し、意思決定を支援する。",revenue:"データAPI・アラートのサブスクリプション",example:"Planet、Maxar、BlackSkyの高頻度観測"}
    ],
    pnt: [
      {title:"自動運転・ロボットの高精度測位",customer:"自動車、建機、農機、ドローン事業者",use:"GNSS補正情報を配信し、センチメートル級の位置推定で自動作業を支える。",revenue:"受信機販売＋補正サービス月額",example:"Trimble、準天頂衛星対応の高精度測位"},
      {title:"重要インフラの時刻同期",customer:"通信キャリア、データセンター、電力、金融",use:"基地局や取引システムへ高精度な時刻を配信し、ネットワークを同期する。",revenue:"機器販売＋時刻配信・監視契約",example:"5G基地局、電力系統、金融取引の同期"}
    ],
    ssa: [
      {title:"衛星衝突回避サービス",customer:"衛星オペレーター、コンステレーション事業者",use:"軌道データから接近を予測し、衝突確率と回避マヌーバ案を提供する。",revenue:"衛星数に応じた月額＋緊急解析費",example:"LeoLabs、COMSPOC、Slingshot Aerospace"},
      {title:"打上げ・保険向け軌道リスク評価",customer:"打上げ事業者、宇宙保険会社、政府",use:"予定軌道の混雑度、物体識別、再突入リスクを評価し、引受判断を支える。",revenue:"案件単位の分析レポート＋データライセンス",example:"軌道環境デューデリジェンス、宇宙保険査定"}
    ],
    "data-relay": [
      {title:"地球観測データの即時中継",customer:"観測衛星事業者、防災・安全保障機関",use:"衛星間光通信で観測データを中継し、地上局上空まで待たずに配信する。",revenue:"通信容量・データ量単位の従量課金",example:"Warpspace、Kepler Communicationsの中継網"},
      {title:"月・深宇宙ミッション通信",customer:"月着陸船、ローバー、探査機運用者",use:"中継衛星を経由し、地球から見えない場所の通信と航法を支援する。",revenue:"ミッション期間・帯域ごとのサービス契約",example:"月周回通信中継、月面ローバーの常時接続"}
    ],
    lunar: [
      {title:"月面ペイロード輸送",customer:"宇宙機関、大学、探査機器・素材メーカー",use:"観測装置や技術実証品を月面まで運び、設置・通信・データ取得を支援する。",revenue:"搭載重量ごとの輸送費＋運用費",example:"ispace、Intuitive Machines、Astrobotic"},
      {title:"月面モビリティとデータ販売",customer:"科学機関、資源探査企業、政府",use:"ローバーで広域を走行し、地形・温度・資源候補のデータを収集する。",revenue:"ミッション受託＋取得データのライセンス",example:"Lunar Outpost、月面ローバー実証"}
    ],
    "space-resources": [
      {title:"月面資源の探査データ",customer:"政府、月面インフラ・エネルギー事業者",use:"水氷や鉱物の分布をセンサーで調べ、着陸地点や設備配置の判断材料を提供する。",revenue:"探査ミッション受託＋データ販売",example:"極域の水資源探査、ispaceの資源データ構想"},
      {title:"現地資源利用（ISRU）設備",customer:"月面基地・長期探査ミッション",use:"レゴリスや水氷から酸素、水、建材、推進剤を製造し、地球からの輸送を減らす。",revenue:"装置販売・リース＋生成量連動課金",example:"月面酸素製造、レゴリス由来建材"}
    ],
    "space-solar": [
      {title:"遠隔地・災害地域への電力供給",customer:"政府、電力会社、災害対応機関",use:"宇宙で発電した電力を無線で必要地点へ送り、地上設備が乏しい場所を支える。",revenue:"電力量契約＋受電設備の提供",example:"低軌道からの電力ビーミング実証"},
      {title:"24時間型クリーン電源",customer:"電力会社、大規模需要家",use:"昼夜や天候に左右されにくい軌道上発電を地上系統へ供給する。",revenue:"長期電力購入契約（PPA）",example:"Space Solar、Virtus Solisの商用構想"}
    ],
    "on-orbit": [
      {title:"衛星寿命延長・燃料補給",customer:"静止衛星・高価値衛星の保有者",use:"ドッキングして姿勢制御や燃料補給を行い、交換打上げより低コストで運用を延ばす。",revenue:"成功報酬型ミッション契約＋年額",example:"Northrop Grumman MEV、Orbit Fab"},
      {title:"デブリ除去・運用終了支援",customer:"政府、衛星事業者、打上げ事業者",use:"故障衛星やロケット上段を捕獲し、安全な軌道へ移動または再突入させる。",revenue:"対象物1件ごとの除去契約",example:"Astroscale、ClearSpaceの除去ミッション"}
    ],
    "space-logistics": [
      {title:"軌道上ラストマイル輸送",customer:"ライドシェア利用の衛星事業者",use:"打上げ後の衛星を宇宙タグで希望高度・軌道面へ運び、投入制約を解消する。",revenue:"衛星重量・ΔV・輸送先に応じた運賃",example:"D-Orbit ION、Exotrail、Impulse Space"},
      {title:"宇宙実験品の地球帰還",customer:"製薬、素材、研究機関",use:"微小重力で製造・実験したサンプルを保冷・管理しながら地上へ戻す。",revenue:"搭載容積・重量ごとの往復輸送費",example:"ElevationSpaceの地球帰還サービス"}
    ],
    "space-biotechnology": [
      {title:"微小重力を使った創薬研究",customer:"製薬会社、大学、バイオベンチャー",use:"微小重力で高品質なタンパク質結晶や細胞モデルを作り、標的探索を効率化する。",revenue:"実験枠販売＋装置利用・解析費",example:"Space Tango、Yuriの自動実験プラットフォーム"},
      {title:"宇宙でのバイオ医薬品製造",customer:"バイオ医薬品メーカー、再生医療企業",use:"地上では作りにくい結晶・組織を軌道上で製造し、高付加価値製品として帰還させる。",revenue:"製造受託＋成果物販売",example:"BioOrbitの微小重力バイオ製造構想"}
    ],
    "satellite-kits": [
      {title:"大学向けCubeSat教育キット",customer:"大学、高専、研究室",use:"標準部品、手順書、試験支援を組み合わせ、学生が衛星開発と運用を実践する。",revenue:"キット販売＋研修・打上げ支援費",example:"GomSpace、ISISPACE、Pumpkin Space Systems"},
      {title:"企業の宇宙実証プラットフォーム",customer:"通信、半導体、素材、IoT企業",use:"標準衛星バスに新製品を搭載し、短期間で軌道上実証を行う。",revenue:"衛星バス利用料＋統合・運用費",example:"EnduroSat、ArkEdge Space、Open Cosmos"}
    ],
    "space-memorial": [
      {title:"軌道・月面メモリアル",customer:"個人、遺族、葬祭事業者",use:"少量の遺灰や記念品をカプセル化し、軌道、月面、深宇宙へ届ける。",revenue:"カプセル単位のプラン料金",example:"Celestis、Elysium Spaceのメモリアル便"},
      {title:"成層圏メモリアル体験",customer:"個人、ペットオーナー、葬祭会社",use:"高高度気球で記念品を成層圏へ運び、地球映像と飛行証明を提供する。",revenue:"フライトパッケージ販売",example:"Beyond Burials、Aura Flights"}
    ],
    iot: [
      {title:"遠隔設備の衛星IoT監視",customer:"電力、資源、建設、自治体",use:"圏外のパイプライン、タンク、気象計から少量データを定期送信し、異常を検知する。",revenue:"端末販売＋回線月額＋メッセージ課金",example:"Myriota、Lacuna Space、Iridium IoT"},
      {title:"コンテナ・車両の追跡",customer:"物流会社、商社、レンタル資産事業者",use:"国境や海上を移動する資産の位置・温度・開閉状態を継続的に把握する。",revenue:"デバイス＋資産1台あたりの月額",example:"ORBCOMM、衛星対応資産トラッカー"}
    ],
    weather: [
      {title:"洪水・山火事の早期警戒",customer:"自治体、消防、インフラ、保険会社",use:"衛星・気象データをAIで解析し、発生可能性と影響範囲をアラートする。",revenue:"地域単位のSaaS契約＋緊急解析費",example:"Tomorrow.io、衛星熱観測、洪水モニタリング"},
      {title:"高頻度・局地気象予測",customer:"航空、海運、再エネ、イベント事業者",use:"独自衛星と地上データを組み合わせ、運航や発電に必要な地点別予報を提供する。",revenue:"API利用量・拠点数に応じた月額",example:"Spire Global、ウェザーニューズ"}
    ],
    agriculture: [
      {title:"作物生育と施肥の最適化",customer:"農家、農協、農機・種苗・食品企業",use:"衛星画像から生育差、水分、病害兆候を把握し、散布や収穫の場所と時期を決める。",revenue:"圃場面積ごとのSaaS料金",example:"サグリ、Pixxel、精密農業プラットフォーム"},
      {title:"森林管理・炭素MRV",customer:"林業、自治体、カーボンクレジット事業者",use:"伐採、劣化、森林量を継続観測し、炭素吸収量の測定・報告・検証に使う。",revenue:"面積単位のモニタリング契約＋報告書",example:"衛星画像を用いた森林クレジット検証"}
    ],
    mobility: [
      {title:"船舶・航空の運航最適化",customer:"船社、航空会社、物流事業者",use:"測位、気象、AIS、通信を統合し、燃料・遅延・安全リスクが少ないルートを提案する。",revenue:"機体・船舶単位の月額＋分析API",example:"Spire Globalの海運・航空データ"},
      {title:"グローバル物流可視化",customer:"荷主、商社、3PL、製造業",use:"輸送中の車両・船舶・コンテナを一つの画面で追跡し、到着予測を更新する。",revenue:"追跡対象数に応じたSaaS課金",example:"衛星AIS・位置情報を使ったETA予測"}
    ],
    finance: [
      {title:"パラメトリック災害保険",customer:"損害保険、再保険、政府、農業金融",use:"衛星で洪水域や干ばつを客観計測し、条件到達時に迅速に保険金を支払う。",revenue:"リスクモデル利用料＋契約手数料",example:"Floodbase、衛星データ連動型農業保険"},
      {title:"経済活動のオルタナティブデータ",customer:"資産運用会社、銀行、商社",use:"工場稼働、港湾在庫、駐車場、作付面積を観測し、業績や需給予測へ利用する。",revenue:"データフィードの年間ライセンス",example:"Orbital Insight、衛星画像による在庫推定"}
    ],
    construction: [
      {title:"地盤沈下・構造物変位監視",customer:"鉄道、道路、電力、自治体、建設会社",use:"衛星SARでミリメートル級の地表変位を定期計測し、点検箇所を絞り込む。",revenue:"監視エリア・期間ごとの契約",example:"InSARによる道路・堤防・橋梁周辺監視"},
      {title:"工事進捗の遠隔確認",customer:"発注者、金融機関、ゼネコン",use:"広域の建設現場を定期撮影し、造成・資材・工程の変化をダッシュボード化する。",revenue:"現場単位の月額＋画像アーカイブ",example:"衛星画像とデジタルツインの工程管理"}
    ],
    entertainment: [
      {title:"成層圏・宇宙旅行体験",customer:"富裕層、旅行会社、法人イベント",use:"高高度気球や宇宙船から地球の曲率と暗い宇宙を体験する商品を提供する。",revenue:"座席・貸切パッケージ販売",example:"Virgin Galactic、Space Perspective"},
      {title:"宇宙ライブ映像・XR教育",customer:"放送、イベント、学校、科学館",use:"宇宙からの映像や軌道データをライブ配信・XR化し、教育・ブランド体験へ活用する。",revenue:"配信権、制作費、チケット・ライセンス",example:"ISSライブ、宇宙イベント配信、VR宇宙体験"}
    ],
    security: [
      {title:"商用衛星によるISR",customer:"防衛・安全保障機関、海上保安、国境管理",use:"光学・SAR・電波データを融合し、拠点・船舶・移動体の変化を把握する。",revenue:"データ購入契約＋分析・タスキング費",example:"Capella Space、HawkEye 360、商用SAR"},
      {title:"レジリエント通信・PNT",customer:"政府、重要インフラ、防災機関",use:"分散型衛星網で通信・測位の冗長経路を確保し、障害や妨害時にも運用を継続する。",revenue:"容量予約＋専用サービス契約",example:"分散型SATCOM、代替PNT、Starshield"}
    ],
    marketing: [
      {title:"新規出店・商圏評価",customer:"小売、外食、不動産、金融機関",use:"人流、土地利用、駐車場、競合店舗を統合し、出店候補地の売上ポテンシャルを比較する。",revenue:"店舗・エリア数に応じたSaaS課金",example:"CARTO、Esri、Placer.aiのロケーション分析"},
      {title:"需要・競合変化の継続監視",customer:"メーカー、投資家、自治体",use:"施設拡張、交通量、人口移動などの変化を時系列で捉え、販売・投資計画を更新する。",revenue:"データAPI＋定期レポート契約",example:"Orbital Insight、LocationMind"}
    ],
    "geospatial-analytics": [
      {title:"変化検知API",customer:"行政SaaS、物流、保険、建設、メディア",use:"複数衛星画像から建物、道路、浸水、伐採などの変化だけを抽出してAPI配信する。",revenue:"APIコール・解析面積による従量課金",example:"UP42、スペースシフト、Descartes Labs"},
      {title:"業務判断まで含む分析レポート",customer:"経営企画、政府、金融、コンサルティング",use:"衛星データを現場・統計データと統合し、拠点配置やリスク対応の提案まで提供する。",revenue:"プロジェクト受託＋継続モニタリング",example:"地理空間インテリジェンス、定期アラート"}
    ],
    fisheries: [
      {title:"漁場予測サービス",customer:"漁業者、漁協、水産会社",use:"海面温度、海色、潮流、気象から魚群が集まりやすい海域を予測し、燃料と探索時間を削減する。",revenue:"船・組合単位の月額サービス",example:"衛星海況を用いた漁場ナビゲーション"},
      {title:"養殖場の環境・給餌管理",customer:"養殖事業者、飼料会社、保険会社",use:"衛星と生簀IoTから水温・赤潮・成長を把握し、給餌と出荷判断を最適化する。",revenue:"生簀・海域単位のSaaS＋機器費",example:"Umitron、赤潮・海況モニタリング"}
    ],
    "environment-monitoring": [
      {title:"メタン排出源の特定",customer:"石油・ガス、鉱業、政府、ESG評価機関",use:"衛星から大規模漏洩を検出し、排出源と推定量を設備単位で報告する。",revenue:"施設監視の年額＋緊急タスキング",example:"GHGSat、AIRMO、Kayrros"},
      {title:"都市熱・大気汚染モニタリング",customer:"自治体、不動産、電力、ヘルスケア",use:"熱赤外・大気データからヒートアイランドや汚染の分布を可視化し、対策地域を選ぶ。",revenue:"都市・施設単位の分析契約",example:"SatVu、ハイパースペクトル環境監視"}
    ],
    "terrain-mapping": [
      {title:"3D都市モデル・デジタルツイン",customer:"自治体、建設、不動産、ゲーム・XR",use:"衛星画像と標高データから広域3Dモデルを作り、都市計画やシミュレーションに使う。",revenue:"モデル制作費＋更新・利用ライセンス",example:"スペースデータ、衛星由来3D都市モデル"},
      {title:"高頻度地図更新",customer:"地図、自動運転、物流、防災事業者",use:"新設道路、建物、災害変化を衛星で検知し、地図データの更新候補を自動生成する。",revenue:"更新データAPI＋地域ライセンス",example:"Maxar、Airbus、BlackSkyの画像基盤"}
    ],
    "public-health": [
      {title:"感染症リスクの早期警戒",customer:"保健当局、自治体、製薬、保険",use:"降雨、気温、水域、植生、人流から蚊媒介感染症などの発生リスクを地域別に予測する。",revenue:"地域・人口規模に応じた分析契約",example:"BlueDot、衛星環境データを使う疾病リスク地図"},
      {title:"災害時の医療アクセス分析",customer:"政府、国際機関、NGO、医療物流",use:"洪水・道路寸断・人口分布を重ね、診療所や物資を優先配備する地点を決める。",revenue:"緊急対応契約＋平時のSaaS利用料",example:"Cloud to Street、人道支援向け地理空間分析"}
    ],
    "maritime-monitoring": [
      {title:"ダークシップ・違法操業検知",customer:"海上保安、防衛、水産当局、NGO",use:"AISを切った船舶をSAR・光学・電波で検出し、行動履歴とリスクを提示する。",revenue:"監視海域・期間ごとの契約＋アラート",example:"Unseenlabs、HawkEye 360、Global Fishing Watch"},
      {title:"港湾混雑・到着時刻予測",customer:"港湾、船社、荷主、金融・商社",use:"衛星AISと気象から船舶の到着、滞船、積み替え状況を予測し、物流計画を改善する。",revenue:"船舶・港湾データのサブスクリプション",example:"Spire Global、Kpler、CLS"}
    ]
  };
  const EARTH_MEDIA = {type:"resource",url:"https://earthobservatory.nasa.gov/",title:"NASA Earth Observatory",caption:"衛星が捉えた地球の写真と、観測データが現場でどう読まれるかを確認できます。",source:"NASA公式"};
  const MEDIA = {
    launch:{type:"resource",url:"https://www.spacex.com/vehicles/starship/",title:"再使用ロケットの技術構成",caption:"機体、推進、打上げ、回収を一つのシステムとして理解するための公式資料です。",source:"SpaceX公式"},
    lunar:{type:"resource",url:"https://www.nasa.gov/humans-in-space/artemis/",title:"Artemis 月探査アーキテクチャ",caption:"月輸送、月面活動、通信・科学ミッションの関係を確認できる公式資料です。",source:"NASA公式"},
    "earth-observation":EARTH_MEDIA,weather:EARTH_MEDIA,agriculture:EARTH_MEDIA,finance:EARTH_MEDIA,construction:EARTH_MEDIA,"geospatial-analytics":EARTH_MEDIA,fisheries:EARTH_MEDIA,"environment-monitoring":EARTH_MEDIA,"terrain-mapping":EARTH_MEDIA,"public-health":EARTH_MEDIA,"maritime-monitoring":EARTH_MEDIA,
    "space-biotechnology":{type:"resource",url:"https://www.nasa.gov/international-space-station/space-station-research-and-technology/",title:"Space Station Research & Technology",caption:"ISSで行われる微小重力研究の写真、実験テーマ、成果を確認できます。",source:"NASA公式"},
    ssa:{type:"resource",url:"https://www.esa.int/Space_Safety/Space_Debris",title:"Space Debris",caption:"デブリ監視、軌道環境、宇宙活動の安全性を解説する公式ビジュアル資料です。",source:"ESA公式"},
    "on-orbit":{type:"resource",url:"https://www.esa.int/Space_Safety/Space_Debris",title:"Space Debris",caption:"デブリ除去や持続可能な軌道利用を理解するための公式資料です。",source:"ESA公式"}
  };
  const market = (base, detail) => ({
    ...base,
    detail: {
      market2025: { ...pending },
      futureMarket: { year: "2035", ...pending },
      companies: [], startups: [], outlook: "市場動向を調査中です。", keywords: base.bullets || [], businessCases: BUSINESS_CASES[base.id] || [], media: MEDIA[base.id] || null,
      ...detail
    }
  });

  window.MARKETS = [
    market({id:"launch",section:"upstream",num:"01",title:"ロケット・打上げ",subtitle:"Launch Services",icon:"🚀",desc:"衛星・探査機を軌道へ輸送するための打上げサービス。",bullets:["小型・大型ロケット","ライドシェア","射場・運用"]},{companies:["SpaceX","Blue Origin","Rocket Lab","三菱重工業","インターステラテクノロジズ"],startups:[{name:"Stoke Space",description:"完全再使用型ロケットの高速ターンアラウンドを開発。"},{name:"Firefly Aerospace",description:"小・中型打上げと月輸送を一体展開。"},{name:"スペースワン",description:"日本発の小型衛星向け打上げサービスを推進。"}],outlook:"小型衛星コンステレーションの拡大を背景に、低コスト化、高頻度化、再使用化が競争軸です。"}),
    market({id:"satellite-manufacturing",section:"upstream",num:"02",title:"衛星製造",subtitle:"Satellite Manufacturing",icon:"🛰️",desc:"通信・観測・測位衛星などの設計、製造、試験を担う領域。",bullets:["小型衛星","コンステレーション","部材・コンポーネント"]},{companies:["Airbus Defence and Space","Lockheed Martin","Thales Alenia Space","三菱電機","NEC"],startups:[{name:"K2 Space",description:"大型・高性能衛星バスの低コスト化を目指す。"},{name:"Axelspace",description:"小型衛星の設計・製造と地球観測サービスを展開。"},{name:"ArkEdge Space",description:"超小型衛星コンステレーションを開発。"}],outlook:"標準バスの採用、量産化、ソフトウェア定義化により、短納期・低コストの衛星供給が加速します。"}),
    market({id:"components",section:"upstream",num:"03",title:"部品・材料",subtitle:"Components & Materials",icon:"🧩",desc:"衛星・ロケットを構成する電子部品、光学部品、構造材など。",bullets:["半導体・センサー","光学・通信部品","軽量・耐熱材料"]},{companies:["Honeywell","RTX","L3Harris Technologies","古河電気工業","IHIエアロスペース"],startups:[{name:"CesiumAstro",description:"宇宙向けフェーズドアレイ通信装置を開発。"},{name:"Morpheus Space",description:"小型衛星向け電気推進システムを提供。"},{name:"Pale Blue",description:"水を推進剤とする小型衛星エンジンを開発。"}],outlook:"小型化、高信頼性、耐放射線性に加え、サプライチェーン強靱化と量産対応が重要になります。"}),
    market({id:"ground-station",section:"upstream",num:"04",title:"地上局",subtitle:"Ground Segment",icon:"📡",desc:"衛星との通信、管制、データ受信を支える地上インフラ。",bullets:["衛星管制","データ受信","アンテナ設備"]},{companies:["KSAT","SSC","Viasat","AWS Ground Station","Infostellar"],startups:[{name:"Leaf Space",description:"共有型の地上局ネットワークを展開。"},{name:"Atlas Space Operations",description:"クラウド型の衛星通信・管制基盤を提供。"},{name:"Infostellar",description:"地上局共有プラットフォームStellarStationを展開。"}],outlook:"衛星数の増加に伴い、クラウド連携、地上局の共同利用、自動運用への需要が高まります。"}),
    market({id:"communications",section:"infrastructure",num:"01",title:"通信衛星",subtitle:"Satellite Communications",icon:"📶",desc:"衛星通信を通じて地上・海上・航空を接続する基盤。",bullets:["ブロードバンド","Direct-to-Device","衛星間通信"]},{companies:["SpaceX","Eutelsat OneWeb","Viasat","SES","スカパーJSAT"],startups:[{name:"Astranis",description:"小型静止通信衛星による地域ブロードバンドを展開。"},{name:"AST SpaceMobile",description:"一般スマートフォンへの衛星直接通信を開発。"},{name:"Warpspace",description:"光通信による衛星間データ中継網を構築。"}],outlook:"低軌道コンステレーション、スマートフォン直接通信、NTN統合が市場拡大を牽引します。"}),
    market({id:"earth-observation",section:"infrastructure",num:"02",title:"地球観測",subtitle:"Earth Observation",icon:"🌍",desc:"光学・SAR・電波などで地球環境や産業活動を観測。",bullets:["光学画像","SAR","環境モニタリング"]},{companies:["Planet Labs","Maxar Intelligence","BlackSky","パスコ","Synspective"],startups:[{name:"Umbra",description:"高分解能SARデータを商用提供。"},{name:"ICEYE",description:"小型SAR衛星群による高頻度観測を展開。"},{name:"QPS研究所",description:"日本発の小型SAR衛星コンステレーションを構築。"}],outlook:"防災、インフラ、農業、保険、安全保障で高頻度データとAI解析の需要が拡大します。"}),
    market({id:"pnt",section:"infrastructure",num:"03",title:"測位・航法・時刻同期",subtitle:"PNT",icon:"🧭",desc:"高精度な位置・航法・時刻情報を提供する社会インフラ。",bullets:["GNSS","高精度測位","時刻配信"]},{companies:["Trimble","Hexagon","Septentrio","三菱電機","ソフトバンク"],startups:[{name:"Xona Space Systems",description:"低軌道衛星による高精度PNTサービスを開発。"},{name:"TrustPoint",description:"次世代の商用GNSSコンステレーションを構想。"},{name:"MetCom",description:"準天頂衛星対応の高精度測位技術を展開。"}],outlook:"自動運転、ドローン、ロボット需要に加え、GNSS妨害に強い代替PNTが重要になります。"}),
    market({id:"ssa",section:"infrastructure",num:"04",title:"宇宙状況把握",subtitle:"Space Situational Awareness",icon:"🔭",desc:"軌道上物体や宇宙天気を監視し、安全な宇宙活動を支援。",bullets:["デブリ監視","衝突回避","宇宙天気"]},{companies:["LeoLabs","Slingshot Aerospace","COMSPOC","NorthStar Earth & Space","アストロスケール"],startups:[{name:"Privateer",description:"宇宙物体データを統合する可視化基盤を提供。"},{name:"Vyoma",description:"宇宙配備型センサーによる軌道監視を開発。"},{name:"Star Signal Solutions",description:"日本発の衛星運用・SSA技術を開発。"}],outlook:"衛星とデブリの増加を受け、精密追跡、衝突確率評価、運用自動化が不可欠になります。"}),
    market({id:"data-relay",section:"infrastructure",num:"05",title:"データ中継",subtitle:"Data Relay",icon:"🔁",desc:"宇宙・地上間のデータ伝送を高速化・効率化する仕組み。",bullets:["衛星間リンク","光通信","中継ネットワーク"]},{companies:["SpaceX","Telesat","Mynaric","NEC","スカパーJSAT"],startups:[{name:"Kepler Communications",description:"低軌道の光データ中継ネットワークを構築。"},{name:"Rivada Space Networks",description:"衛星間リンクを用いたセキュア通信網を計画。"},{name:"Warpspace",description:"地球観測衛星向け光通信中継サービスを開発。"}],outlook:"観測データ量の急増により、光衛星間通信とリアルタイムダウンリンクが成長領域です。"}),
    market({id:"lunar",section:"new",num:"01",title:"月面・深宇宙探査",subtitle:"Lunar & Deep Space",icon:"🌙",desc:"月面・惑星・深宇宙を対象とした探査、科学、インフラ構築。",bullets:["月面ローバー","探査機","月面通信"]},{companies:["NASA","Lockheed Martin","Intuitive Machines","ispace","三菱電機"],startups:[{name:"Astrobotic",description:"月面輸送と月面技術実証を展開。"},{name:"Lunar Outpost",description:"月面ローバーとモビリティを開発。"},{name:"ispace",description:"月面輸送サービスと月資源データ事業を推進。"}],outlook:"政府ミッションを基盤に、民間月輸送、通信、電力、モビリティなど周辺サービスが形成されます。"}),
    market({id:"space-resources",section:"new",num:"02",title:"宇宙資源",subtitle:"Space Resources",icon:"⛏️",desc:"月や小惑星などの資源探索、採掘、利用を目指す新市場。",bullets:["資源探査","ISRU","採掘技術"]},{companies:["ispace","Blue Origin","Lockheed Martin","Airbus Defence and Space"],startups:[{name:"Interlune",description:"月面ヘリウム3などの資源利用を構想。"},{name:"AstroForge",description:"小惑星資源探査・精製の実証を進める。"},{name:"Lunar Resources",description:"月資源を用いた製造・電力技術を開発。"}],outlook:"長期的な月面活動を支える水・酸素・建材の現地調達が、初期の事業機会と見込まれます。"}),
    market({id:"space-solar",section:"new",num:"03",title:"宇宙太陽光発電",subtitle:"Space Solar Power",icon:"☀️",desc:"宇宙空間で発電したエネルギーを地上へ送電する構想。",bullets:["発電衛星","無線送電","受電設備"]},{companies:["Airbus Defence and Space","Northrop Grumman","三菱重工業","IHI"],startups:[{name:"Aetherflux",description:"低軌道衛星からの宇宙太陽光送電を開発。"},{name:"Space Solar",description:"大規模な宇宙太陽光発電システムを設計。"},{name:"Virtus Solis",description:"モジュール型の軌道上発電・無線送電を構想。"}],outlook:"技術実証から商用化まで長期を要しますが、脱炭素電源と災害時電力として期待されています。"}),
    market({id:"on-orbit",section:"new",num:"04",title:"軌道上サービス",subtitle:"On-orbit Services",icon:"🛠️",desc:"軌道上での点検、補給、修理、寿命延長、デブリ除去。",bullets:["点検・修理","燃料補給","デブリ除去"]},{companies:["Northrop Grumman","アストロスケール","Airbus Defence and Space","Thales Alenia Space"],startups:[{name:"Orbit Fab",description:"軌道上燃料補給インフラを開発。"},{name:"Starfish Space",description:"衛星寿命延長・廃棄用の小型宇宙機を開発。"},{name:"ClearSpace",description:"宇宙デブリ除去ミッションを推進。"}],outlook:"衛星資産の高額化と持続可能性規制を背景に、寿命延長、補給、除去の需要が立ち上がります。"}),
    market({id:"space-logistics",section:"new",num:"05",title:"宇宙輸送",subtitle:"Space Logistics",icon:"📦",desc:"軌道間・月面間の輸送サービスや宇宙物流ネットワーク。",bullets:["軌道間輸送","月面輸送","宇宙港"]},{companies:["SpaceX","Northrop Grumman","D-Orbit","ispace","三菱重工業"],startups:[{name:"Impulse Space",description:"軌道間輸送機と深宇宙輸送サービスを開発。"},{name:"Exotrail",description:"スペースタグによるラストマイル輸送を提供。"},{name:"ElevationSpace",description:"宇宙環境利用と地球帰還サービスを開発。"}],outlook:"ライドシェア後の軌道投入、月輸送、地球帰還など物流の細分化が新たな市場を生みます。"}),
    market({id:"space-biotechnology",section:"new",num:"06",title:"宇宙バイオテクノロジー",subtitle:"Space Biotechnology",icon:"🧬",desc:"微小重力や放射線環境を利用し、創薬・細胞・食品・材料研究を進める領域。",bullets:["微小重力実験","創薬・結晶化","細胞・組織培養"]},{companies:["Redwire","Axiom Space","Space Tango","JAMSS"],startups:[{name:"Yuri",description:"宇宙バイオ実験の自動化プラットフォームを開発。"},{name:"BioOrbit",description:"微小重力を利用したバイオ医薬品製造を目指す。"},{name:"Space Bio-Laboratories",description:"重力環境を活用した生命科学研究を支援。"}],outlook:"宇宙ステーションの民間利用拡大により、地上では難しい創薬・再生医療・食品研究の事業化が期待されます。"}),
    market({id:"satellite-kits",section:"new",num:"07",title:"人工衛星キット",subtitle:"Satellite Kits & Platforms",icon:"🧰",desc:"標準化された部品や衛星バスを組み合わせ、教育・実証・商用衛星を短期間で構築。",bullets:["CubeSatキット","標準衛星バス","教育・技術実証"]},{companies:["GomSpace","EnduroSat","ISISPACE","Pumpkin Space Systems"],startups:[{name:"Alba Orbital",description:"超小型衛星プラットフォームと打上げ支援を提供。"},{name:"Open Cosmos",description:"衛星開発から運用・データ利用までを統合。"},{name:"ArkEdge Space",description:"超小型衛星の設計・製造・運用を展開。"}],outlook:"部品標準化とクラウド運用により、大学・企業・自治体が宇宙実証へ参入しやすくなります。"}),
    market({id:"space-memorial",section:"new",num:"08",title:"宇宙葬・メモリアル",subtitle:"Space Memorial Services",icon:"🕯️",desc:"遺灰や記念品を成層圏・軌道・月面・深宇宙へ送り届けるメモリアルサービス。",bullets:["軌道上メモリアル","月面メモリアル","成層圏フライト"]},{companies:["Celestis","Elysium Space","Space NTK"],startups:[{name:"Beyond Burials",description:"成層圏でのメモリアル散骨サービスを展開。"},{name:"Aura Flights",description:"高高度気球を利用した成層圏メモリアルを提供。"},{name:"Space NTK",description:"日本発の宇宙葬・宇宙関連サービスを展開。"}],outlook:"打上げ機会の増加と小型ペイロードサービスの普及により、個人向け宇宙体験の一分野として拡大が見込まれます。"}),
    market({id:"iot",section:"downstream",num:"01",title:"通信・IoT",subtitle:"Connectivity & IoT",icon:"📡",desc:"衛星通信を活用し、地上・海上・航空の機器を接続。",bullets:["遠隔監視","資産トラッキング","非常時通信"]},{companies:["Iridium","Globalstar","Inmarsat","KDDI","ソラコム"],startups:[{name:"Lacuna Space",description:"低消費電力の衛星IoT接続を提供。"},{name:"Myriota",description:"省電力・低コストの直接衛星IoTを展開。"},{name:"サグリ",description:"衛星データとAIを農業・行政業務に活用。"}],outlook:"圏外地域の設備、物流、環境センサーを低消費電力で接続する需要が拡大します。"}),
    market({id:"weather",section:"downstream",num:"02",title:"防災・気象",subtitle:"Disaster & Weather",icon:"🌦️",desc:"衛星データを活用した気象予測や災害モニタリング。",bullets:["早期警戒","被害把握","リアルタイム監視"]},{companies:["Tomorrow.io","Spire Global","ウェザーニューズ","パスコ","日本気象協会"],startups:[{name:"Muon Space",description:"気候・環境監視向け衛星プラットフォームを開発。"},{name:"Hydrosat",description:"熱赤外データで水資源や干ばつを分析。"},{name:"天地人",description:"衛星データを活用した土地評価・気候リスク分析を提供。"}],outlook:"気候変動と激甚災害を背景に、高頻度観測とAI予測を組み合わせた早期警戒が伸長します。"}),
    market({id:"agriculture",section:"downstream",num:"03",title:"農業・林業",subtitle:"Agriculture & Forestry",icon:"🌱",desc:"作物・森林の状態を把握し、生産性向上や保全に活用。",bullets:["生育監視","収穫予測","森林管理"]},{companies:["Bayer","John Deere","Trimble","クボタ","パスコ"],startups:[{name:"Pixxel",description:"ハイパースペクトル衛星で作物状態を分析。"},{name:"Satellogic",description:"高頻度地球観測データを農業などへ提供。"},{name:"サグリ",description:"衛星データとAIで農地管理を効率化。"}],outlook:"精密農業、炭素クレジット、森林保全で、衛星データと現場データの統合利用が進みます。"}),
    market({id:"mobility",section:"downstream",num:"04",title:"物流・モビリティ",subtitle:"Logistics & Mobility",icon:"🚚",desc:"船舶、航空、陸上物流の追跡・運航最適化を支援。",bullets:["位置追跡","運航最適化","ルート分析"]},{companies:["ORBCOMM","Spire Global","Hexagon","トヨタ自動車","日本郵船"],startups:[{name:"Hivemapper",description:"分散型の高頻度地図データを構築。"},{name:"Aistech Space",description:"宇宙ベースの船舶・航空監視を展開。"},{name:"LocationMind",description:"位置情報解析と人流データ活用を推進。"}],outlook:"衛星測位・通信・観測を統合し、グローバル物流の可視化と自律運航を支える需要が拡大します。"}),
    market({id:"finance",section:"downstream",num:"05",title:"金融・保険",subtitle:"Finance & Insurance",icon:"📊",desc:"地球観測データをリスク評価や保険査定に活用。",bullets:["災害リスク","農業保険","ESG評価"]},{companies:["Swiss Re","Munich Re","Jupiter Intelligence","三井住友海上","東京海上日動"],startups:[{name:"Descartes Labs",description:"地理空間データ解析をリスク評価へ活用。"},{name:"Floodbase",description:"衛星データによる洪水リスク分析とパラメトリック保険を支援。"},{name:"Gaia Vision",description:"衛星データで森林・カーボンクレジットを分析。"}],outlook:"自然災害の頻発により、客観的な衛星データを用いた迅速な査定と気候リスク評価が普及します。"}),
    market({id:"construction",section:"downstream",num:"06",title:"建設・インフラ",subtitle:"Construction & Infrastructure",icon:"🏗️",desc:"広域インフラの監視、変位把握、維持管理を効率化。",bullets:["橋梁・道路","地盤変動","都市計画"]},{companies:["Trimble","Hexagon","Bentley Systems","鹿島建設","パスコ"],startups:[{name:"Satelytics",description:"衛星画像でインフラ異常や漏洩を検知。"},{name:"4DV Analytics",description:"SAR解析で地盤・構造物変位を監視。"},{name:"Synspective",description:"SAR衛星データで災害・インフラ変動を解析。"}],outlook:"老朽化するインフラの広域・定期監視に、衛星SARとデジタルツインの連携が進みます。"}),
    market({id:"entertainment",section:"downstream",num:"07",title:"エンターテインメント",subtitle:"Entertainment",icon:"🎬",desc:"宇宙旅行、映像、教育、XRなど新しい体験を創出。",bullets:["宇宙旅行","映像・配信","教育・体験"]},{companies:["Virgin Galactic","Blue Origin","Axiom Space","Space Adventures","バスキュール"],startups:[{name:"Space Perspective",description:"気球型宇宙旅行による成層圏体験を開発。"},{name:"Zero 2 Infinity",description:"気球を用いた成層圏体験を展開。"},{name:"amulapo",description:"宇宙体験コンテンツと宇宙教育を展開。"}],outlook:"有人宇宙飛行だけでなく、成層圏体験、ライブ映像、XR、教育など裾野の広い市場形成が期待されます。"}),
    market({id:"security",section:"downstream",num:"08",title:"安全・保障",subtitle:"Security",icon:"🛡️",desc:"通信、観測、測位を通じて国家・社会の安全を支える領域。",bullets:["監視・偵察","セキュア通信","レジリエンス"]},{companies:["Lockheed Martin","Northrop Grumman","L3Harris Technologies","三菱電機","NEC"],startups:[{name:"HawkEye 360",description:"衛星による無線周波数信号の検知・分析を提供。"},{name:"Capella Space",description:"全天候型SAR画像を高頻度で提供。"},{name:"iQPS",description:"小型SAR衛星による準リアルタイム観測を目指す。"}],outlook:"デュアルユース技術、商用衛星データ、分散型コンステレーションによるレジリエンス強化が進みます。"}),
    market({id:"marketing",section:"downstream",num:"09",title:"マーケティング・商圏分析",subtitle:"Marketing & Location Intelligence",icon:"🎯",desc:"衛星画像・位置情報・人流データから商圏、需要、競合環境を分析。",bullets:["商圏分析","需要予測","位置情報マーケティング"]},{companies:["Esri","CARTO","Precisely","ゼンリン"],startups:[{name:"Orbital Insight",description:"地理空間データから経済・産業活動を解析。"},{name:"Placer.ai",description:"位置情報を利用した商圏・人流分析を提供。"},{name:"LocationMind",description:"位置情報と衛星データの高度解析を展開。"}],outlook:"衛星画像と人流・購買データを組み合わせ、店舗配置や市場変化を高頻度に把握する利用が広がります。"}),
    market({id:"geospatial-analytics",section:"downstream",num:"10",title:"地理空間解析・データ提供",subtitle:"Geospatial Analytics",icon:"🗺️",desc:"複数の衛星データをAIで解析し、意思決定に使える情報として提供。",bullets:["衛星データ解析","AI画像認識","分析API・レポート"]},{companies:["Esri","Maxar Intelligence","Airbus Intelligence","パスコ"],startups:[{name:"Descartes Labs",description:"大規模な地理空間データ解析基盤を提供。"},{name:"UP42",description:"衛星データと解析アルゴリズムのマーケットプレイスを展開。"},{name:"スペースシフト",description:"SAR衛星データに特化したAI解析を開発。"}],outlook:"生データ販売から、業務課題に直結する解析結果・API・アラート提供へ価値の中心が移っています。"}),
    market({id:"fisheries",section:"downstream",num:"11",title:"水産・養殖",subtitle:"Fisheries & Aquaculture",icon:"🐟",desc:"海面温度、海色、船舶位置を分析し、漁場探索や養殖環境の監視を支援。",bullets:["漁場予測","赤潮・海況監視","養殖管理"]},{companies:["CLS","Spire Global","e-GEOS","オーシャンソリューションテクノロジー"],startups:[{name:"OceanMind",description:"衛星・船舶データで漁業活動と違法操業を分析。"},{name:"Umitron",description:"衛星データとIoTを活用した養殖管理を展開。"},{name:"Global Fishing Watch",description:"衛星・AISデータから漁船活動を可視化。"}],outlook:"海洋環境変化と水産資源管理の高度化を背景に、衛星・IoT・AIを統合した養殖・漁業支援が拡大します。"}),
    market({id:"environment-monitoring",section:"downstream",num:"12",title:"環境・大気モニタリング",subtitle:"Environment & Atmospheric Monitoring",icon:"🌫️",desc:"温室効果ガス、紫外線、大気汚染、熱異常を衛星から広域かつ継続的に監視。",bullets:["温室効果ガス","大気汚染・紫外線","排出源モニタリング"]},{companies:["GHGSat","Planet Labs","Kayrros","ウェザーニューズ"],startups:[{name:"SatVu",description:"熱赤外衛星で都市・産業活動の熱情報を観測。"},{name:"AIRMO",description:"衛星搭載センサーで温室効果ガス排出を監視。"},{name:"Pixxel",description:"ハイパースペクトル画像で環境変化を分析。"}],outlook:"企業の排出量管理や規制対応に向け、個別施設まで識別する高分解能・高頻度観測が求められます。"}),
    market({id:"terrain-mapping",section:"downstream",num:"13",title:"地形・地図",subtitle:"Terrain & Mapping",icon:"⛰️",desc:"光学・SAR・測位データから標高、地形変化、三次元地図を作成。",bullets:["デジタル標高モデル","3D都市モデル","地図更新"]},{companies:["Maxar Intelligence","Airbus Intelligence","Esri","パスコ"],startups:[{name:"BlackSky",description:"高頻度衛星画像と分析で変化を把握。"},{name:"Satellogic",description:"高分解能地球観測データをグローバルに提供。"},{name:"スペースデータ",description:"衛星データからデジタルツインを構築。"}],outlook:"自動運転、防災、建設、都市計画で更新頻度の高い3D地理空間データの需要が伸びます。"}),
    market({id:"public-health",section:"downstream",num:"14",title:"公衆衛生・疫病監視",subtitle:"Public Health & Epidemic Intelligence",icon:"🩺",desc:"気象、土地利用、水環境、人流を分析し、感染症や健康リスクの早期把握を支援。",bullets:["感染症リスク","媒介生物環境","医療アクセス分析"]},{companies:["Esri","Planet Labs","Maxar Intelligence","IBM"],startups:[{name:"BlueDot",description:"多様なデータをAI解析し感染症リスクを監視。"},{name:"Fever",description:"地理空間・環境情報を活用する公衆衛生分析を推進。"},{name:"Cloud to Street",description:"衛星データで洪水曝露と人道リスクを分析。"}],outlook:"気候変動による感染症分布の変化に備え、衛星・気象・人流データを統合した早期警戒が重要になります。"}),
    market({id:"maritime-monitoring",section:"downstream",num:"15",title:"海洋・船舶監視",subtitle:"Maritime Domain Awareness",icon:"🚢",desc:"AIS、電波、SAR、光学データを統合し、船舶の位置・活動・異常を監視。",bullets:["船舶追跡","違法操業検知","海上安全"]},{companies:["Spire Global","Kpler","HawkEye 360","CLS"],startups:[{name:"Unseenlabs",description:"衛星から船舶の電波信号を検知・識別。"},{name:"Kleos Space",description:"無線周波数データで海洋活動を監視。"},{name:"Synspective",description:"SARデータで夜間・悪天候下の船舶や海域を観測。"}],outlook:"AISを切った船舶も含めた海洋状況把握に向け、複数センサーのデータ融合が進みます。"})
  ];
})();
